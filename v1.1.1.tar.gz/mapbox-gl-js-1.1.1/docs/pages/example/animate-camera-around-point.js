/*---
title: Animate map camera around a point
description: Animate map camera around a point.
tags:
  - camera
pathname: /mapbox-gl-js/example/animate-camera-around-point/
---*/
import Example from '../../components/example';
import html from './animate-camera-around-point.html';
export default Example(html);
