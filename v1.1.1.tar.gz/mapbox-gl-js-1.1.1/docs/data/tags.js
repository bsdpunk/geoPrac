export const tags = {
    "styles": "Styles",
    "layers": "Layers",
    "sources": "Sources",
    "user-interaction": "User interaction",
    "camera": "Camera",
    "controls-and-overlays": "Controls and overlays",
    "geocoder": "Geocoder",
    "browser-support": "Browser support",
    "internationalization": "Internationalization support"
};
