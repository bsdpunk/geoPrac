module.exports = {
    plugins: [
        require('postcss-inline-svg')
    ]
}
